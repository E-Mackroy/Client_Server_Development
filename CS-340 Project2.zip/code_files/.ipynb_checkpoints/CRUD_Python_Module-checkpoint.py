# CRUD_Python_Module.py

import certifi
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from dotenv import load_dotenv
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError, PyMongoError

load_dotenv()


@dataclass
class CRUDResult:
    ok: bool
    detail: Union[str, Dict[str, Any], List[Dict[str, Any]], int, None] = None

    def as_list(self) -> List[Dict[str, Any]]:
        if isinstance(self.detail, list):
            return self.detail
        if self.detail is None:
            return []
        return [self.detail]


class AnimalShelter:
    """CRUD operations for aac.animals"""

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        uri: Optional[str] = None,
        db_name: Optional[str] = None,
        collection_name: Optional[str] = None,
    ) -> None:
        # Defaults for your Codio setup
        db_name = db_name or os.getenv("MONGO_DB", "aac")
        collection_name = collection_name or os.getenv("MONGO_COLLECTION", "animals")

        try:
            if username and password:
                # Local Mongo, authenticate against the same DB we read (aac)
                self.client = MongoClient(
                    host="127.0.0.1",
                    port=27017,
                    username=username,
                    password=password,
                    authSource=db_name,
                )
            else:
                # Fallback to URI (Atlas etc.). No creds in code here.
                uri = uri or os.getenv("MONGO_URI")
                if not uri:
                    raise ValueError(
                        "Provide username/password or set MONGO_URI in the environment."
                    )
                if uri.startswith("mongodb+srv://"):
                    self.client = MongoClient(uri, tlsCAFile=certifi.where())
                else:
                    self.client = MongoClient(uri)
        except Exception as e:
            raise RuntimeError(f"MongoClient connection failed: {e}")

        self.db = self.client[db_name]
        self.col: Collection = self.db[collection_name]

    # CREATE
    def create(self, data: Dict[str, Any]) -> CRUDResult:
        if not data or not isinstance(data, dict):
            return CRUDResult(False, "create() requires a non-empty dict")
        try:
            res = self.col.insert_one(data)
            return CRUDResult(True, {"inserted_id": str(res.inserted_id)})
        except DuplicateKeyError:
            return CRUDResult(False, "duplicate key")
        except PyMongoError as e:
            return CRUDResult(False, f"create() error: {e}")

    # READ
    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: int = 0,
    ) -> CRUDResult:
        try:
            cursor = self.col.find(query or {}, projection or {})
            if limit and limit > 0:
                cursor = cursor.limit(limit)
            docs = list(cursor)
            for d in docs:
                if "_id" in d:
                    d["_id"] = str(d["_id"])
            return CRUDResult(True, docs)
        except PyMongoError as e:
            return CRUDResult(False, f"read() error: {e}")

    # UPDATE
    def update(
        self, query: Dict[str, Any], new_values: Dict[str, Any], many: bool = False
    ) -> CRUDResult:
        if not query or not new_values:
            return CRUDResult(False, "update() needs query and new_values")
        try:
            op = self.col.update_many if many else self.col.update_one
            res = op(query, {"$set": new_values})
            return CRUDResult(
                True, {"matched": res.matched_count, "modified": res.modified_count}
            )
        except PyMongoError as e:
            return CRUDResult(False, f"update() error: {e}")

    # DELETE
    def delete(self, query: Dict[str, Any], many: bool = False) -> CRUDResult:
        if not query:
            return CRUDResult(False, "delete() needs a non-empty query")
        try:
            op = self.col.delete_many if many else self.col.delete_one
            res = op(query)
            return CRUDResult(True, res.deleted_count)
        except PyMongoError as e:
            return CRUDResult(False, f"delete() error: {e}")








